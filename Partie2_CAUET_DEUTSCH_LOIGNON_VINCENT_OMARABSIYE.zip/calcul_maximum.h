
liste calcul_maximum(Graph *g);
liste calcul_stable(Graph *g,int taille);
