#include "util.h"
#include "calcul_maximum_exact.h"
#define BUFFER_SIZE 5000

int sat2graph(Graph *g, const char* filename);
